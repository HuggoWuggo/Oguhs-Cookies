This is a totally legal gambling game.

Run the python file and hope to win!!!

THIS ONLY WORKS ON WINDOWS!!!!